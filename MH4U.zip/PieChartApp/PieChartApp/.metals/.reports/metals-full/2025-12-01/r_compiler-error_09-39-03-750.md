error id: 2231967A81E4FA8A9DD04E7BCC30AB2E
file://<WORKSPACE>/app/services/MentalHealthPredictor.scala
### java.util.NoSuchElementException: head of empty String

occurred in the presentation compiler.



action parameters:
offset: 1765
uri: file://<WORKSPACE>/app/services/MentalHealthPredictor.scala
text:
```scala
package services

import com.github.tototoshi.csv.CSVReader
import java.io.File

object MentalHealthPredictor {

  /** Safely convert a string to Double; return 0.0 if conversion fails */
  private def toDoubleSafe(s: String): Double = try s.toDouble catch { case _: NumberFormatException => 0.0 }

  /** Predict outputs based on nearest neighbors in CSV */
  def predict(input: Map[String, Any], csvPath: String = "data/mental_health_dataset.csv"): Map[String, Any] = {

    val csvFile = new File(csvPath)
    val reader = CSVReader.open(csvFile)
    val rows = reader.allWithHeaders()
    reader.close()

    // Fields
    val numericFields = Seq("age", "stress_level", "sleep_hours", "physical_activity_days")
    val categoricalFields = Seq("gender", "employment_status", "work_environment", "mental_health_history", "seeks_treatment")

    /** Calculate distance between a CSV row and the input */
    def distance(row: Map[String, String]): Double = {
      // Numeric distance
      val numericDist = numericFields.map { f =>
        toDoubleSafe(row.getOrElse(f, "0")) - input(f).asInstanceOf[Double]
      }.map(d => d * d).sum

      // Categorical distance (0 if match, 1 if not)
      val catDist = categoricalFields.map { f =>
        if (row.getOrElse(f, "") == input(f)) 0.0 else 1.0
      }.sum

      math.sqrt(numericDist) + catDist
    }

    // Find 5 nearest neighbors
    val nearest = rows.sortBy(distance).take(5)

    /** Safe average for numeric fields */
    def avg(field: String): Double = nearest.map(r => toDoubleSafe(r.getOrElse(field, "0"))).sum / nearest.size

    // Majority vote for mental_health_risk
    val risk = nearest.groupBy(_("mental_health_risk"))
      .map { case (k, v) => k -> v.size }
      .maxBy(_._2)._1

    @@LinkedHashMap(
  "depression_score" -> avg("depression_score"),
  "anxiety_score" -> avg("anxiety_score"),
  "social_support_score" -> avg("social_support_score"),
  "productivity_score" -> avg("productivity_score"),
  "mental_health_risk" -> risk
)
  }
}

```


presentation compiler configuration:
Scala version: 2.13.18
Classpath:
<HOME>/.cache/coursier/v1/https/repo1.maven.org/maven2/org/scala-lang/scala-library/2.13.18/scala-library-2.13.18.jar [exists ]
Options:





#### Error stacktrace:

```
scala.collection.StringOps$.head$extension(StringOps.scala:1124)
	scala.meta.internal.metals.ClassfileComparator.compare(ClassfileComparator.scala:30)
	scala.meta.internal.metals.ClassfileComparator.compare(ClassfileComparator.scala:3)
	java.base/java.util.PriorityQueue.siftUpUsingComparator(PriorityQueue.java:660)
	java.base/java.util.PriorityQueue.siftUp(PriorityQueue.java:637)
	java.base/java.util.PriorityQueue.offer(PriorityQueue.java:330)
	java.base/java.util.PriorityQueue.add(PriorityQueue.java:311)
	scala.meta.internal.metals.ClasspathSearch.$anonfun$search$3(ClasspathSearch.scala:32)
	scala.meta.internal.metals.ClasspathSearch.$anonfun$search$3$adapted(ClasspathSearch.scala:26)
	scala.collection.IterableOnceOps.foreach(IterableOnce.scala:630)
	scala.collection.IterableOnceOps.foreach$(IterableOnce.scala:628)
	scala.collection.AbstractIterator.foreach(Iterator.scala:1313)
	scala.meta.internal.metals.ClasspathSearch.search(ClasspathSearch.scala:26)
	scala.meta.internal.metals.WorkspaceSymbolProvider.search(WorkspaceSymbolProvider.scala:107)
	scala.meta.internal.metals.MetalsSymbolSearch.search$1(MetalsSymbolSearch.scala:114)
	scala.meta.internal.metals.MetalsSymbolSearch.search(MetalsSymbolSearch.scala:118)
	scala.meta.internal.pc.AutoImportsProvider.autoImports(AutoImportsProvider.scala:58)
	scala.meta.internal.pc.ScalaPresentationCompiler.$anonfun$autoImports$1(ScalaPresentationCompiler.scala:399)
	scala.meta.internal.pc.CompilerAccess.withSharedCompiler(CompilerAccess.scala:148)
	scala.meta.internal.pc.CompilerAccess.$anonfun$withInterruptableCompiler$1(CompilerAccess.scala:92)
	scala.meta.internal.pc.CompilerAccess.$anonfun$onCompilerJobQueue$1(CompilerAccess.scala:209)
	scala.meta.internal.pc.CompilerJobQueue$Job.run(CompilerJobQueue.scala:152)
	java.base/java.util.concurrent.ThreadPoolExecutor.runWorker(ThreadPoolExecutor.java:1136)
	java.base/java.util.concurrent.ThreadPoolExecutor$Worker.run(ThreadPoolExecutor.java:635)
	java.base/java.lang.Thread.run(Thread.java:840)
```
#### Short summary: 

java.util.NoSuchElementException: head of empty String
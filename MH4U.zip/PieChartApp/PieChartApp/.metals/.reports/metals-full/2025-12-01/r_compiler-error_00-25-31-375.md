error id: 2231967A81E4FA8A9DD04E7BCC30AB2E
file://<WORKSPACE>/app/services/PieChartService.scala
### java.util.NoSuchElementException: head of empty String

occurred in the presentation compiler.



action parameters:
offset: 1027
uri: file://<WORKSPACE>/app/services/PieChartService.scala
text:
```scala
package services

import com.github.tototoshi.csv._
import org.knowm.xchart.{PieChart, PieChartBuilder, BitmapEncoder}
import java.io.{File, FileWriter, ByteArrayOutputStream}
import java.nio.file.{Files, Paths, StandardCopyOption}
import java.util.Base64
import javax.imageio.ImageIO
import scala.collection.mutable

object PieChartService {

  System.setProperty("java.awt.headless", "true")

  // Path to writable CSV
  private val dataFolder = "data"
  private val csvFilePath = s"$dataFolder/mental_health_dataset.csv"

  private val data: mutable.Map[String, Double] = mutable.Map()

  /** Ensure CSV exists, copy from conf if first run */
  private def ensureCSVExists(): Unit = {
    val csvFile = new File(csvFilePath)
    if (!csvFile.exists()) {
      Files.createDirectories(Paths.get(dataFolder))
      val origCsv = new File("conf/mental_health_dataset.csv")
      if (origCsv.exists()) {
        Files.copy(origCsv.toPath, csvFile.toPath, StandardCopyOption.REPLACE_EXISTING)
      } else {
        val writer = @@CSVWriter.open(csvFile)
        writer.writeRow(Seq("gender", "Value"))
        writer.close()
      }
    }
  }

  /** Load CSV into memory */
  private def loadDataFromCSV(): Unit = {
    ensureCSVExists()
    val csvFile = new File(csvFilePath)
    val reader = CSVReader.open(csvFile)
    try {
      reader.allWithHeaders().foreach { row =>
        val category = row.getOrElse("gender", "Unknown")
        val value = row.get("Value").flatMap(s => scala.util.Try(s.toDouble).toOption).getOrElse(0.0)
        if (value > 0) data.update(category, data.getOrElse(category, 0.0) + value)
      }
    } finally reader.close()
  }

  /** Add or update a category/value */
  def addData(category: String, value: Double): Unit = synchronized {
    val newValue = data.getOrElse(category, 0.0) + value
    data.update(category, newValue)

    // Rewrite CSV from memory
    val writer = CSVWriter.open(new FileWriter(csvFilePath))
    writer.writeRow(Seq("gender", "Value"))
    data.foreach { case (cat, v) => writer.writeRow(Seq(cat, v.toString)) }
    writer.close()
  }

  /** Generate Base64 PNG chart */
  def generatePieChartBase64(): String = {
    if (data.isEmpty) data.update("No Data", 1)
    val chart: PieChart = new PieChartBuilder()
      .width(600)
      .height(400)
      .title("Interactive Pie Chart")
      .build()
    data.foreach { case (label, value) => chart.addSeries(label, value) }
    val baos = new ByteArrayOutputStream()
    val img = BitmapEncoder.getBufferedImage(chart)
    ImageIO.write(img, "png", baos)
    Base64.getEncoder.encodeToString(baos.toByteArray)
  }

  // Load CSV on startup
  loadDataFromCSV()
}

```


presentation compiler configuration:
Scala version: 2.13.18
Classpath:
<HOME>/.cache/coursier/v1/https/repo1.maven.org/maven2/org/scala-lang/scala-library/2.13.18/scala-library-2.13.18.jar [exists ]
Options:





#### Error stacktrace:

```
scala.collection.StringOps$.head$extension(StringOps.scala:1124)
	scala.meta.internal.metals.ClassfileComparator.compare(ClassfileComparator.scala:30)
	scala.meta.internal.metals.ClassfileComparator.compare(ClassfileComparator.scala:3)
	java.base/java.util.PriorityQueue.siftUpUsingComparator(PriorityQueue.java:660)
	java.base/java.util.PriorityQueue.siftUp(PriorityQueue.java:637)
	java.base/java.util.PriorityQueue.offer(PriorityQueue.java:330)
	java.base/java.util.PriorityQueue.add(PriorityQueue.java:311)
	scala.meta.internal.metals.ClasspathSearch.$anonfun$search$3(ClasspathSearch.scala:32)
	scala.meta.internal.metals.ClasspathSearch.$anonfun$search$3$adapted(ClasspathSearch.scala:26)
	scala.collection.IterableOnceOps.foreach(IterableOnce.scala:630)
	scala.collection.IterableOnceOps.foreach$(IterableOnce.scala:628)
	scala.collection.AbstractIterator.foreach(Iterator.scala:1313)
	scala.meta.internal.metals.ClasspathSearch.search(ClasspathSearch.scala:26)
	scala.meta.internal.metals.WorkspaceSymbolProvider.search(WorkspaceSymbolProvider.scala:107)
	scala.meta.internal.metals.MetalsSymbolSearch.search$1(MetalsSymbolSearch.scala:114)
	scala.meta.internal.metals.MetalsSymbolSearch.search(MetalsSymbolSearch.scala:118)
	scala.meta.internal.pc.AutoImportsProvider.autoImports(AutoImportsProvider.scala:58)
	scala.meta.internal.pc.ScalaPresentationCompiler.$anonfun$autoImports$1(ScalaPresentationCompiler.scala:399)
	scala.meta.internal.pc.CompilerAccess.withSharedCompiler(CompilerAccess.scala:148)
	scala.meta.internal.pc.CompilerAccess.$anonfun$withInterruptableCompiler$1(CompilerAccess.scala:92)
	scala.meta.internal.pc.CompilerAccess.$anonfun$onCompilerJobQueue$1(CompilerAccess.scala:209)
	scala.meta.internal.pc.CompilerJobQueue$Job.run(CompilerJobQueue.scala:152)
	java.base/java.util.concurrent.ThreadPoolExecutor.runWorker(ThreadPoolExecutor.java:1136)
	java.base/java.util.concurrent.ThreadPoolExecutor$Worker.run(ThreadPoolExecutor.java:635)
	java.base/java.lang.Thread.run(Thread.java:840)
```
#### Short summary: 

java.util.NoSuchElementException: head of empty String
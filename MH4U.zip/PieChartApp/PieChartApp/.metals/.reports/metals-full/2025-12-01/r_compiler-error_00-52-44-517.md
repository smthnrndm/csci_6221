error id: 2231967A81E4FA8A9DD04E7BCC30AB2E
file://<WORKSPACE>/app/services/MentalHealthPredictor.scala
### java.util.NoSuchElementException: head of empty String

occurred in the presentation compiler.



action parameters:
offset: 351
uri: file://<WORKSPACE>/app/services/MentalHealthPredictor.scala
text:
```scala
package services

import com.github.tototoshi.csv.CSVReader
import java.io.File

object MentalHealthPredictor {

  // Predicts numeric & categorical outputs based on nearest neighbors
  def predict(input: Map[String, Any], csvPath: String = "data/mental_health_dataset.csv"): Map[String, Any] = {

    val csvFile = new File(csvPath)
    val reader = @@CSVReader.open(csvFile)
    val rows = reader.allWithHeaders()
    reader.close()

    // Compute distance between input and a row
    def distance(row: Map[String, String]): Double = {
      // Numeric fields
      val ageDiff = row.getOrElse("age", "0").toDouble - input("age").asInstanceOf[Double]
      val stressDiff = row.getOrElse("stress_level", "0").toDouble - input("stress_level").asInstanceOf[Double]
      val sleepDiff = row.getOrElse("sleep_hours", "0").toDouble - input("sleep_hours").asInstanceOf[Double]
      val activityDiff = row.getOrElse("physical_activity_days", "0").toDouble - input("physical_activity_days").asInstanceOf[Double]

      val numericDist = math.sqrt(ageDiff*ageDiff + stressDiff*stressDiff + sleepDiff*sleepDiff + activityDiff*activityDiff)

      // Categorical fields (0 = match, 1 = mismatch)
      val categoricalFields = Seq("gender", "employment_status", "work_environment", "mental_health_history", "seeks_treatment")
      val catDist = categoricalFields.map(f => if(row.getOrElse(f,"") == input(f)) 0 else 1).sum.toDouble

      numericDist + catDist
    }

    // Find 5 nearest neighbors
    val nearest = rows.sortBy(distance).take(5)

    // Predict numeric outputs by averaging
    def avg(field: String): Double = nearest.map(r => r.getOrElse(field, "0").toDouble).sum / nearest.size

    // Predict categorical output by majority vote
    val risk = nearest.groupBy(_("mental_health_risk")).mapValues(_.size).maxBy(_._2)._1

    Map(
      "depression_score" -> avg("depression_score"),
      "anxiety_score" -> avg("anxiety_score"),
      "social_support_score" -> avg("social_support_score"),
      "productivity_score" -> avg("productivity_score"),
      "mental_health_risk" -> risk
    )
  }

}

```


presentation compiler configuration:
Scala version: 2.13.18
Classpath:
<HOME>/.cache/coursier/v1/https/repo1.maven.org/maven2/org/scala-lang/scala-library/2.13.18/scala-library-2.13.18.jar [exists ]
Options:





#### Error stacktrace:

```
scala.collection.StringOps$.head$extension(StringOps.scala:1124)
	scala.meta.internal.metals.ClassfileComparator.compare(ClassfileComparator.scala:30)
	scala.meta.internal.metals.ClassfileComparator.compare(ClassfileComparator.scala:3)
	java.base/java.util.PriorityQueue.siftUpUsingComparator(PriorityQueue.java:660)
	java.base/java.util.PriorityQueue.siftUp(PriorityQueue.java:637)
	java.base/java.util.PriorityQueue.offer(PriorityQueue.java:330)
	java.base/java.util.PriorityQueue.add(PriorityQueue.java:311)
	scala.meta.internal.metals.ClasspathSearch.$anonfun$search$3(ClasspathSearch.scala:32)
	scala.meta.internal.metals.ClasspathSearch.$anonfun$search$3$adapted(ClasspathSearch.scala:26)
	scala.collection.IterableOnceOps.foreach(IterableOnce.scala:630)
	scala.collection.IterableOnceOps.foreach$(IterableOnce.scala:628)
	scala.collection.AbstractIterator.foreach(Iterator.scala:1313)
	scala.meta.internal.metals.ClasspathSearch.search(ClasspathSearch.scala:26)
	scala.meta.internal.metals.WorkspaceSymbolProvider.search(WorkspaceSymbolProvider.scala:107)
	scala.meta.internal.metals.MetalsSymbolSearch.search$1(MetalsSymbolSearch.scala:114)
	scala.meta.internal.metals.MetalsSymbolSearch.search(MetalsSymbolSearch.scala:118)
	scala.meta.internal.pc.AutoImportsProvider.autoImports(AutoImportsProvider.scala:58)
	scala.meta.internal.pc.ScalaPresentationCompiler.$anonfun$autoImports$1(ScalaPresentationCompiler.scala:399)
	scala.meta.internal.pc.CompilerAccess.withSharedCompiler(CompilerAccess.scala:148)
	scala.meta.internal.pc.CompilerAccess.$anonfun$withInterruptableCompiler$1(CompilerAccess.scala:92)
	scala.meta.internal.pc.CompilerAccess.$anonfun$onCompilerJobQueue$1(CompilerAccess.scala:209)
	scala.meta.internal.pc.CompilerJobQueue$Job.run(CompilerJobQueue.scala:152)
	java.base/java.util.concurrent.ThreadPoolExecutor.runWorker(ThreadPoolExecutor.java:1136)
	java.base/java.util.concurrent.ThreadPoolExecutor$Worker.run(ThreadPoolExecutor.java:635)
	java.base/java.lang.Thread.run(Thread.java:840)
```
#### Short summary: 

java.util.NoSuchElementException: head of empty String
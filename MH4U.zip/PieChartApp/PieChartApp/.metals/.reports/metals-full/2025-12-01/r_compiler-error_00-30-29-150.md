error id: 2231967A81E4FA8A9DD04E7BCC30AB2E
file://<WORKSPACE>/app/controllers/PieChartController.scala
### java.util.NoSuchElementException: head of empty String

occurred in the presentation compiler.



action parameters:
offset: 676
uri: file://<WORKSPACE>/app/controllers/PieChartController.scala
text:
```scala
package controllers

import play.api.mvc._
import javax.inject._
import services.PieChartService
import play.api.data._
import play.api.data.Forms._
import play.api.data.format.Formats._
import play.api.libs.json.Json

@Singleton
class PieChartController @Inject()(cc: ControllerComponents) extends AbstractController(cc) {

  val chartForm: Form[(String, Double)] = Form(
    tuple(
      "category" -> nonEmptyText,
      "value" -> of[Double]
    )
  )

  /** Show chart page with original CSV data */
  def showChart() = Action { implicit request =>
    val base64Chart = PieChartService.generatePieChartBase64()
    val currentData = PieChartService.getCurrentData()
    @@Ok(views.html.chartWithInput(base64Chart, currentData))
  }

  /** Handle AJAX addData */
  def addDataAjax() = Action { implicit request =>
    chartForm.bindFromRequest().fold(
      _ => BadRequest(Json.obj("status" -> "error", "message" -> "Invalid input")),
      { case (category, value) =>
        PieChartService.addData(category, value)
        val updatedChart = PieChartService.generatePieChartBase64()
        Ok(Json.obj("status" -> "success", "chart" -> updatedChart))
      }
    )
  }

  /** Optional non-AJAX fallback */
  def addData() = Action { implicit request =>
    chartForm.bindFromRequest().fold(
      _ => Redirect(routes.PieChartController.showChart())
            .flashing("error" -> "Invalid input"),
      { case (category, value) =>
        PieChartService.addData(category, value)
        Redirect(routes.PieChartController.showChart())
          .flashing("success" -> s"Added $category -> $value")
      }
    )
  }
}

```


presentation compiler configuration:
Scala version: 2.13.18
Classpath:
<HOME>/.cache/coursier/v1/https/repo1.maven.org/maven2/org/scala-lang/scala-library/2.13.18/scala-library-2.13.18.jar [exists ]
Options:





#### Error stacktrace:

```
scala.collection.StringOps$.head$extension(StringOps.scala:1124)
	scala.meta.internal.metals.ClassfileComparator.compare(ClassfileComparator.scala:30)
	scala.meta.internal.metals.ClassfileComparator.compare(ClassfileComparator.scala:3)
	java.base/java.util.PriorityQueue.siftUpUsingComparator(PriorityQueue.java:660)
	java.base/java.util.PriorityQueue.siftUp(PriorityQueue.java:637)
	java.base/java.util.PriorityQueue.offer(PriorityQueue.java:330)
	java.base/java.util.PriorityQueue.add(PriorityQueue.java:311)
	scala.meta.internal.metals.ClasspathSearch.$anonfun$search$3(ClasspathSearch.scala:32)
	scala.meta.internal.metals.ClasspathSearch.$anonfun$search$3$adapted(ClasspathSearch.scala:26)
	scala.collection.IterableOnceOps.foreach(IterableOnce.scala:630)
	scala.collection.IterableOnceOps.foreach$(IterableOnce.scala:628)
	scala.collection.AbstractIterator.foreach(Iterator.scala:1313)
	scala.meta.internal.metals.ClasspathSearch.search(ClasspathSearch.scala:26)
	scala.meta.internal.metals.WorkspaceSymbolProvider.search(WorkspaceSymbolProvider.scala:107)
	scala.meta.internal.metals.MetalsSymbolSearch.search$1(MetalsSymbolSearch.scala:114)
	scala.meta.internal.metals.MetalsSymbolSearch.search(MetalsSymbolSearch.scala:118)
	scala.meta.internal.pc.AutoImportsProvider.autoImports(AutoImportsProvider.scala:58)
	scala.meta.internal.pc.ScalaPresentationCompiler.$anonfun$autoImports$1(ScalaPresentationCompiler.scala:399)
	scala.meta.internal.pc.CompilerAccess.withSharedCompiler(CompilerAccess.scala:148)
	scala.meta.internal.pc.CompilerAccess.$anonfun$withInterruptableCompiler$1(CompilerAccess.scala:92)
	scala.meta.internal.pc.CompilerAccess.$anonfun$onCompilerJobQueue$1(CompilerAccess.scala:209)
	scala.meta.internal.pc.CompilerJobQueue$Job.run(CompilerJobQueue.scala:152)
	java.base/java.util.concurrent.ThreadPoolExecutor.runWorker(ThreadPoolExecutor.java:1136)
	java.base/java.util.concurrent.ThreadPoolExecutor$Worker.run(ThreadPoolExecutor.java:635)
	java.base/java.lang.Thread.run(Thread.java:840)
```
#### Short summary: 

java.util.NoSuchElementException: head of empty String
error id: 2231967A81E4FA8A9DD04E7BCC30AB2E
file://<WORKSPACE>/app/controllers/MentalHealthController.scala
### java.util.NoSuchElementException: head of empty String

occurred in the presentation compiler.



action parameters:
offset: 1033
uri: file://<WORKSPACE>/app/controllers/MentalHealthController.scala
text:
```scala
package controllers

import javax.inject._
import play.api.mvc._
import play.api.data._
import play.api.data.Forms._
import play.api.data.format.Formats._   // needed for Double binding
import services.MentalHealthPredictor
import play.api.i18n.I18nSupport

@Singleton
class MentalHealthController @Inject()(cc: MessagesControllerComponents) extends MessagesAbstractController(cc) with I18nSupport {

  // Form for the 9 input fields
  val predictionForm: Form[(
    Double, String, String, String, String, String, Double, Double, Double
  )] = Form(
    tuple(
      "age" -> of[Double],
      "gender" -> nonEmptyText,
      "employment_status" -> nonEmptyText,
      "work_environment" -> nonEmptyText,
      "mental_health_history" -> nonEmptyText,
      "seeks_treatment" -> nonEmptyText,
      "stress_level" -> of[Double],
      "sleep_hours" -> of[Double],
      "physical_activity_days" -> of[Double]
    )
  )

  /** Show prediction form */
  def showForm = Action { implicit request: MessagesRequest[AnyContent] =>
    Ok(@@views.html.predictMentalHealth(predictionForm, None))
  }

  /** Handle form submission and predict outputs */
  def predict = Action { implicit request: MessagesRequest[AnyContent] =>
    predictionForm.bindFromRequest.fold(
      formWithErrors => Ok(views.html.predictMentalHealth(formWithErrors, None)),
      formData => {
        val inputMap = Map(
          "age" -> formData._1,
          "gender" -> formData._2,
          "employment_status" -> formData._3,
          "work_environment" -> formData._4,
          "mental_health_history" -> formData._5,
          "seeks_treatment" -> formData._6,
          "stress_level" -> formData._7,
          "sleep_hours" -> formData._8,
          "physical_activity_days" -> formData._9
        )

        val prediction = MentalHealthPredictor.predict(inputMap)
        Ok(views.html.predictMentalHealth(predictionForm.fill(formData), Some(prediction)))
      }
    )
  }

}

```


presentation compiler configuration:
Scala version: 2.13.18
Classpath:
<HOME>/.cache/coursier/v1/https/repo1.maven.org/maven2/org/scala-lang/scala-library/2.13.18/scala-library-2.13.18.jar [exists ]
Options:





#### Error stacktrace:

```
scala.collection.StringOps$.head$extension(StringOps.scala:1124)
	scala.meta.internal.metals.ClassfileComparator.compare(ClassfileComparator.scala:30)
	scala.meta.internal.metals.ClassfileComparator.compare(ClassfileComparator.scala:3)
	java.base/java.util.PriorityQueue.siftUpUsingComparator(PriorityQueue.java:660)
	java.base/java.util.PriorityQueue.siftUp(PriorityQueue.java:637)
	java.base/java.util.PriorityQueue.offer(PriorityQueue.java:330)
	java.base/java.util.PriorityQueue.add(PriorityQueue.java:311)
	scala.meta.internal.metals.ClasspathSearch.$anonfun$search$3(ClasspathSearch.scala:32)
	scala.meta.internal.metals.ClasspathSearch.$anonfun$search$3$adapted(ClasspathSearch.scala:26)
	scala.collection.IterableOnceOps.foreach(IterableOnce.scala:630)
	scala.collection.IterableOnceOps.foreach$(IterableOnce.scala:628)
	scala.collection.AbstractIterator.foreach(Iterator.scala:1313)
	scala.meta.internal.metals.ClasspathSearch.search(ClasspathSearch.scala:26)
	scala.meta.internal.metals.WorkspaceSymbolProvider.search(WorkspaceSymbolProvider.scala:107)
	scala.meta.internal.metals.MetalsSymbolSearch.search$1(MetalsSymbolSearch.scala:114)
	scala.meta.internal.metals.MetalsSymbolSearch.search(MetalsSymbolSearch.scala:118)
	scala.meta.internal.pc.AutoImportsProvider.autoImports(AutoImportsProvider.scala:58)
	scala.meta.internal.pc.ScalaPresentationCompiler.$anonfun$autoImports$1(ScalaPresentationCompiler.scala:399)
	scala.meta.internal.pc.CompilerAccess.withSharedCompiler(CompilerAccess.scala:148)
	scala.meta.internal.pc.CompilerAccess.$anonfun$withInterruptableCompiler$1(CompilerAccess.scala:92)
	scala.meta.internal.pc.CompilerAccess.$anonfun$onCompilerJobQueue$1(CompilerAccess.scala:209)
	scala.meta.internal.pc.CompilerJobQueue$Job.run(CompilerJobQueue.scala:152)
	java.base/java.util.concurrent.ThreadPoolExecutor.runWorker(ThreadPoolExecutor.java:1136)
	java.base/java.util.concurrent.ThreadPoolExecutor$Worker.run(ThreadPoolExecutor.java:635)
	java.base/java.lang.Thread.run(Thread.java:840)
```
#### Short summary: 

java.util.NoSuchElementException: head of empty String
error id: 2231967A81E4FA8A9DD04E7BCC30AB2E
file://<WORKSPACE>/app/services/PieChartService.scala
### java.util.NoSuchElementException: head of empty String

occurred in the presentation compiler.



action parameters:
offset: 1352
uri: file://<WORKSPACE>/app/services/PieChartService.scala
text:
```scala
package services

import org.knowm.xchart.{PieChart, PieChartBuilder, BitmapEncoder}
import java.io.{ByteArrayOutputStream, File, FileWriter}
import java.nio.file.{Files, Paths, StandardCopyOption}
import java.util.Base64
import javax.imageio.ImageIO
import com.github.tototoshi.csv._
import scala.collection.mutable

object PieChartService {

  System.setProperty("java.awt.headless", "true")

  private val dataFolder = "data"
  private val csvFilePath = s"$dataFolder/mental_health_dataset.csv"

  // Map holds gender -> count
  private val data: mutable.Map[String, Double] = mutable.Map()

  /** Ensure CSV exists, copy from conf if first run */
  private def ensureCSVExists(): Unit = {
    val csvFile = new File(csvFilePath)
    if (!csvFile.exists()) {
      Files.createDirectories(Paths.get(dataFolder))
      val origCsv = new File("conf/mental_health_dataset.csv")
      if (origCsv.exists()) {
        Files.copy(origCsv.toPath, csvFile.toPath, StandardCopyOption.REPLACE_EXISTING)
      } else {
        val writer = CSVWriter.open(csvFile)
        writer.writeRow(Seq("gender", "Value"))
        writer.close()
      }
    }
  }

  /** Load CSV into memory, filtering employed/self-employed and counting genders */
  private def loadDataFromCSV(): Unit = {
    ensureCSVExists()
    val csvFile = new File(csvFilePath)
    val reader = @@CSVReader.open(csvFile)
    try {
      reader.allWithHeaders().foreach { row =>
        val employment = row.getOrElse("employment_status", "").toLowerCase
        if (employment.contains("employed")) {
          val gender = row.getOrElse("gender", "Unknown").trim
          data.update(gender, data.getOrElse(gender, 0.0) + 1.0)
        }
      }
    } finally reader.close()
  }

  /** Add a new data point (category & value) to the CSV */
  def addData(category: String, value: Double): Unit = synchronized {
    // Update memory
    val newValue = data.getOrElse(category, 0.0) + value
    data.update(category, newValue)

    // Append to CSV
    val csvFile = new File(csvFilePath)
    val writer = CSVWriter.open(new FileWriter(csvFile, true))
    writer.writeRow(Seq("gender", value.toString)) // minimal CSV row for new data points
    writer.close()
  }

  /** Generate Base64 Pie Chart */
  def generatePieChartBase64(): String = {
    if (data.isEmpty) data.update("No Data", 1)
    val chart: PieChart = new PieChartBuilder()
      .width(600)
      .height(400)
      .title("Gender Distribution of Workers")
      .build()
    data.foreach { case (label, value) => chart.addSeries(label, value) }
    val baos = new ByteArrayOutputStream()
    val img = BitmapEncoder.getBufferedImage(chart)
    ImageIO.write(img, "png", baos)
    Base64.getEncoder.encodeToString(baos.toByteArray)
  }

  /** Return a read-only copy of current data */
  def getCurrentData(): Map[String, Double] = data.toMap

  // Load CSV on startup → original chart is available immediately
  loadDataFromCSV()
}

```


presentation compiler configuration:
Scala version: 2.13.18
Classpath:
<HOME>/.cache/coursier/v1/https/repo1.maven.org/maven2/org/scala-lang/scala-library/2.13.18/scala-library-2.13.18.jar [exists ]
Options:





#### Error stacktrace:

```
scala.collection.StringOps$.head$extension(StringOps.scala:1124)
	scala.meta.internal.metals.ClassfileComparator.compare(ClassfileComparator.scala:30)
	scala.meta.internal.metals.ClassfileComparator.compare(ClassfileComparator.scala:3)
	java.base/java.util.PriorityQueue.siftUpUsingComparator(PriorityQueue.java:660)
	java.base/java.util.PriorityQueue.siftUp(PriorityQueue.java:637)
	java.base/java.util.PriorityQueue.offer(PriorityQueue.java:330)
	java.base/java.util.PriorityQueue.add(PriorityQueue.java:311)
	scala.meta.internal.metals.ClasspathSearch.$anonfun$search$3(ClasspathSearch.scala:32)
	scala.meta.internal.metals.ClasspathSearch.$anonfun$search$3$adapted(ClasspathSearch.scala:26)
	scala.collection.IterableOnceOps.foreach(IterableOnce.scala:630)
	scala.collection.IterableOnceOps.foreach$(IterableOnce.scala:628)
	scala.collection.AbstractIterator.foreach(Iterator.scala:1313)
	scala.meta.internal.metals.ClasspathSearch.search(ClasspathSearch.scala:26)
	scala.meta.internal.metals.WorkspaceSymbolProvider.search(WorkspaceSymbolProvider.scala:107)
	scala.meta.internal.metals.MetalsSymbolSearch.search$1(MetalsSymbolSearch.scala:114)
	scala.meta.internal.metals.MetalsSymbolSearch.search(MetalsSymbolSearch.scala:118)
	scala.meta.internal.pc.AutoImportsProvider.autoImports(AutoImportsProvider.scala:58)
	scala.meta.internal.pc.ScalaPresentationCompiler.$anonfun$autoImports$1(ScalaPresentationCompiler.scala:399)
	scala.meta.internal.pc.CompilerAccess.withSharedCompiler(CompilerAccess.scala:148)
	scala.meta.internal.pc.CompilerAccess.$anonfun$withInterruptableCompiler$1(CompilerAccess.scala:92)
	scala.meta.internal.pc.CompilerAccess.$anonfun$onCompilerJobQueue$1(CompilerAccess.scala:209)
	scala.meta.internal.pc.CompilerJobQueue$Job.run(CompilerJobQueue.scala:152)
	java.base/java.util.concurrent.ThreadPoolExecutor.runWorker(ThreadPoolExecutor.java:1136)
	java.base/java.util.concurrent.ThreadPoolExecutor$Worker.run(ThreadPoolExecutor.java:635)
	java.base/java.lang.Thread.run(Thread.java:840)
```
#### Short summary: 

java.util.NoSuchElementException: head of empty String
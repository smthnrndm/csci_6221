error id: file://<WORKSPACE>/piechartapp/build.sbt:
file://<WORKSPACE>/piechartapp/build.sbt
empty definition using pc, found symbol in pc: 
empty definition using semanticdb
empty definition using fallback
non-local guesses:
	 -name.
	 -name#
	 -name().
	 -scala/Predef.name.
	 -scala/Predef.name#
	 -scala/Predef.name().
offset: 0
uri: file://<WORKSPACE>/piechartapp/build.sbt
text:
```scala
@@name := """PieChartApp"""
organization := "com.example"

version := "1.0-SNAPSHOT"

lazy val root = (project in file(".")).enablePlugins(PlayScala)

scalaVersion := "2.13.18"

libraryDependencies += guice
libraryDependencies += "org.scalatestplus.play" %% "scalatestplus-play" % "7.0.2" % Test

libraryDependencies ++= Seq(
  "org.knowm.xchart" % "xchart" % "3.8.2",
  "com.github.tototoshi" %% "scala-csv" % "1.3.10"

// Adds additional packages into Twirl
//TwirlKeys.templateImports += "com.example.controllers._"

// Adds additional packages into conf/routes
// play.sbt.routes.RoutesKeys.routesImport += "com.example.binders._"

```


#### Short summary: 

empty definition using pc, found symbol in pc: 
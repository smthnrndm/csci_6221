error id: file://<WORKSPACE>/app/controllers/HeatMapController.scala:[339..340) in Input.VirtualFile("file://<WORKSPACE>/app/controllers/HeatMapController.scala", "@(jsonString: String)(implicit request: play.api.mvc.RequestHeader)

<!DOCTYPE html>
<html>
<head>
    <title>Mental Health Risk Heatmap</title>
    <script src="https://cdn.plot.ly/plotly-latest.min.js"></script>
</head>
<body>
<h1>Mental Health Risk Heatmap</h1>

<div id="heatmap" style="width: 80%; height: 600px;"></div>

<script type="text/javascript">
    // Parse JSON string into a JavaScript object
    var dataRecords = JSON.parse('@jsonString');

    // Extract unique values for axes and facets
    var genders = [...new Set(dataRecords.map(d => d.gender))];
    var employmentStatuses = [...new Set(dataRecords.map(d => d.employment_status))];
    var workEnvironments = [...new Set(dataRecords.map(d => d.work_environment))];

    var traces = [];

    genders.forEach(function(g) {
        var z = [];
        workEnvironments.forEach(function(we) {
            var row = [];
            employmentStatuses.forEach(function(emp) {
                // find matching record
                var match = dataRecords.find(d => d.employment_status === emp && d.work_environment === we && d.gender === g);
                row.push(match ? match.avg_risk : 0);
            });
            z.push(row);
        });

        traces.push({
            z: z,
            x: employmentStatuses,
            y: workEnvironments,
            type: 'heatmap',
            name: g,
            showscale: true
        });
    });

    var layout = {
        title: 'Mental Health Risk Heatmap',
        xaxis: {title: 'Employment Status'},
        yaxis: {title: 'Work Environment'},
        grid: {rows: 1, columns: 1}
    };

    Plotly.newPlot('heatmap', traces, layout);
</script>
</body>
</html>
")
file://<WORKSPACE>/file:<WORKSPACE>/app/controllers/HeatMapController.scala
file://<WORKSPACE>/app/controllers/HeatMapController.scala:14: error: expected identifier; obtained equals


Current stack trace:
java.base/java.lang.Thread.getStackTrace(Thread.java:1619)
scala.meta.internal.mtags.ScalaToplevelMtags.failMessage(ScalaToplevelMtags.scala:1206)
scala.meta.internal.mtags.ScalaToplevelMtags.$anonfun$reportError$1(ScalaToplevelMtags.scala:1192)
scala.meta.internal.metals.StdReporter.$anonfun$create$1(ReportContext.scala:148)
scala.util.Try$.apply(Try.scala:217)
scala.meta.internal.metals.StdReporter.create(ReportContext.scala:143)
scala.meta.pc.reports.Reporter.create(Reporter.java:10)
scala.meta.internal.mtags.ScalaToplevelMtags.reportError(ScalaToplevelMtags.scala:1189)
scala.meta.internal.mtags.ScalaToplevelMtags.newIdentifier(ScalaToplevelMtags.scala:1095)
scala.meta.internal.mtags.ScalaToplevelMtags.emitType(ScalaToplevelMtags.scala:806)
scala.meta.internal.mtags.ScalaToplevelMtags.$anonfun$loop$19(ScalaToplevelMtags.scala:356)
scala.meta.internal.mtags.MtagsIndexer.withOwner(MtagsIndexer.scala:53)
scala.meta.internal.mtags.MtagsIndexer.withOwner$(MtagsIndexer.scala:50)
scala.meta.internal.mtags.ScalaToplevelMtags.withOwner(ScalaToplevelMtags.scala:49)
scala.meta.internal.mtags.ScalaToplevelMtags.loop(ScalaToplevelMtags.scala:355)
scala.meta.internal.mtags.ScalaToplevelMtags.indexRoot(ScalaToplevelMtags.scala:96)
scala.meta.internal.metals.SemanticdbDefinition$.foreachWithReturnMtags(SemanticdbDefinition.scala:83)
scala.meta.internal.metals.Indexer.indexSourceFile(Indexer.scala:546)
scala.meta.internal.metals.Indexer.$anonfun$reindexWorkspaceSources$3(Indexer.scala:677)
scala.meta.internal.metals.Indexer.$anonfun$reindexWorkspaceSources$3$adapted(Indexer.scala:674)
scala.collection.IterableOnceOps.foreach(IterableOnce.scala:630)
scala.collection.IterableOnceOps.foreach$(IterableOnce.scala:628)
scala.collection.AbstractIterator.foreach(Iterator.scala:1313)
scala.meta.internal.metals.Indexer.reindexWorkspaceSources(Indexer.scala:674)
scala.meta.internal.metals.MetalsLspService.$anonfun$onChange$2(MetalsLspService.scala:912)
scala.runtime.java8.JFunction0$mcV$sp.apply(JFunction0$mcV$sp.scala:18)
scala.concurrent.Future$.$anonfun$apply$1(Future.scala:691)
scala.concurrent.impl.Promise$Transformation.run(Promise.scala:500)
java.base/java.util.concurrent.ThreadPoolExecutor.runWorker(ThreadPoolExecutor.java:1136)
java.base/java.util.concurrent.ThreadPoolExecutor$Worker.run(ThreadPoolExecutor.java:635)
java.base/java.lang.Thread.run(Thread.java:840)

<script type="text/javascript">
            ^
#### Short summary: 

expected identifier; obtained equals
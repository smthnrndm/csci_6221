error id: 2231967A81E4FA8A9DD04E7BCC30AB2E
file://<WORKSPACE>/app/services/HeatMapService.scala
### java.util.NoSuchElementException: head of empty String

occurred in the presentation compiler.



action parameters:
offset: 3231
uri: file://<WORKSPACE>/app/services/HeatMapService.scala
text:
```scala
package services

import org.knowm.xchart.{BitmapEncoder, CategoryChart, CategoryChartBuilder, CategorySeries}
import java.io.ByteArrayOutputStream
import java.util.Base64
import com.github.tototoshi.csv._
import scala.collection.mutable
import scala.jdk.CollectionConverters._
import java.awt.Color

object HeatMapService {

  System.setProperty("java.awt.headless", "true")

  private val csvFilePath = "data/mental_health_dataset.csv"

  /** Map: (employment_status, work_environment) -> avg risk */
  private val heatmapData: mutable.Map[(String, String), Double] = mutable.Map()

  /** Read CSV and aggregate */
  def loadData(): Unit = {
    val reader = CSVReader.open(new java.io.File(csvFilePath))
    try {
      val rows = reader.allWithHeaders()
      val validRows = rows.filter { r =>
        r.get("employment_status").exists(_.nonEmpty) &&
        r.get("work_environment").exists(_.nonEmpty) &&
        r.get("mental_health_risk").exists(_.nonEmpty)
      }

      val grouped = validRows.groupBy(r => (r("employment_status"), r("work_environment")))

      grouped.foreach { case ((emp, work), recs) =>
        val risks = recs.flatMap(r =>
          r.get("mental_health_risk").flatMap {
            case "Low" => Some(0.0)
            case "Medium" => Some(0.5)
            case "High" => Some(1.0)
            case v => scala.util.Try(v.toDouble).toOption
          }
        )
        if (risks.nonEmpty) heatmapData.update((emp, work), risks.sum / risks.size)
      }
    } finally reader.close()
  }

  /** Map a risk value [0.0-1.0] to a color between green → yellow → red */
  private def riskToColor(risk: Double): Color = {
    val clamped = Math.max(0.0, Math.min(1.0, risk))
    if (clamped <= 0.5) {
      // Green to yellow
      val ratio = clamped / 0.5
      new Color((1 - ratio) * 0.0f + ratio * 1.0f, 1.0f, 0.0f) // R,G,B
    } else {
      // Yellow to red
      val ratio = (clamped - 0.5) / 0.5
      new Color(1.0f, (1 - ratio) * 1.0f, 0.0f) // R,G,B
    }
  }

  /** Generate Base64 PNG heatmap with colors */
  def generateHeatMapBase64(): String = {
    if (heatmapData.isEmpty) loadData()

    val xLabels = heatmapData.keys.map(_._1).toSeq.distinct.sorted
    val yLabels = heatmapData.keys.map(_._2).toSeq.distinct.sorted

    val chart: CategoryChart = new CategoryChartBuilder()
      .width(700)
      .height(500)
      .title("Mental Health Risk Heatmap")
      .xAxisTitle("Employment Status")
      .yAxisTitle("Work Environment")
      .build()

    // Add each row as a series
    val seriesList = yLabels.map { y =>
      val yValues = xLabels.map { x =>
        java.lang.Double.valueOf(heatmapData.getOrElse((x, y), 0.0))
      }
      chart.addSeries(y, xLabels.asJava, yValues.asJava)
    }

    // Set colors for each series based on the values
    seriesList.zip(yLabels).foreach { case (series: CategorySeries, y) =>
      val colors = xLabels.map { x =>
        riskToColor(heatmapData.getOrElse((x, y), 0.0))
      }.toArray
      series.setFillColor(colors.head) // XChart allows one color per series; best effort
    }

    chart.getStyler.setPlotGridLinesVisible(false)
    chart.getStyler.setLegendVisible(true)

    val baos = new ByteArrayOutputStream()
    @@BitmapEncoder.saveBitmap(chart, baos, BitmapEncoder.BitmapFormat.PNG)
    Base64.getEncoder.encodeToString(baos.toByteArray)
  }
}

```


presentation compiler configuration:
Scala version: 2.13.18
Classpath:
<HOME>/.cache/coursier/v1/https/repo1.maven.org/maven2/org/scala-lang/scala-library/2.13.18/scala-library-2.13.18.jar [exists ]
Options:





#### Error stacktrace:

```
scala.collection.StringOps$.head$extension(StringOps.scala:1124)
	scala.meta.internal.metals.ClassfileComparator.compare(ClassfileComparator.scala:30)
	scala.meta.internal.metals.ClassfileComparator.compare(ClassfileComparator.scala:3)
	java.base/java.util.PriorityQueue.siftUpUsingComparator(PriorityQueue.java:660)
	java.base/java.util.PriorityQueue.siftUp(PriorityQueue.java:637)
	java.base/java.util.PriorityQueue.offer(PriorityQueue.java:330)
	java.base/java.util.PriorityQueue.add(PriorityQueue.java:311)
	scala.meta.internal.metals.ClasspathSearch.$anonfun$search$3(ClasspathSearch.scala:32)
	scala.meta.internal.metals.ClasspathSearch.$anonfun$search$3$adapted(ClasspathSearch.scala:26)
	scala.collection.IterableOnceOps.foreach(IterableOnce.scala:630)
	scala.collection.IterableOnceOps.foreach$(IterableOnce.scala:628)
	scala.collection.AbstractIterator.foreach(Iterator.scala:1313)
	scala.meta.internal.metals.ClasspathSearch.search(ClasspathSearch.scala:26)
	scala.meta.internal.metals.WorkspaceSymbolProvider.search(WorkspaceSymbolProvider.scala:107)
	scala.meta.internal.metals.MetalsSymbolSearch.search$1(MetalsSymbolSearch.scala:114)
	scala.meta.internal.metals.MetalsSymbolSearch.search(MetalsSymbolSearch.scala:118)
	scala.meta.internal.pc.AutoImportsProvider.autoImports(AutoImportsProvider.scala:58)
	scala.meta.internal.pc.ScalaPresentationCompiler.$anonfun$autoImports$1(ScalaPresentationCompiler.scala:399)
	scala.meta.internal.pc.CompilerAccess.withSharedCompiler(CompilerAccess.scala:148)
	scala.meta.internal.pc.CompilerAccess.$anonfun$withInterruptableCompiler$1(CompilerAccess.scala:92)
	scala.meta.internal.pc.CompilerAccess.$anonfun$onCompilerJobQueue$1(CompilerAccess.scala:209)
	scala.meta.internal.pc.CompilerJobQueue$Job.run(CompilerJobQueue.scala:152)
	java.base/java.util.concurrent.ThreadPoolExecutor.runWorker(ThreadPoolExecutor.java:1136)
	java.base/java.util.concurrent.ThreadPoolExecutor$Worker.run(ThreadPoolExecutor.java:635)
	java.base/java.lang.Thread.run(Thread.java:840)
```
#### Short summary: 

java.util.NoSuchElementException: head of empty String
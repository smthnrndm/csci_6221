error id: file://<WORKSPACE>/app/controllers/HomeController.scala:scala/Singleton#
file://<WORKSPACE>/app/controllers/HomeController.scala
empty definition using pc, found symbol in pc: scala/Singleton#
empty definition using semanticdb

found definition using fallback; symbol Singleton
offset: 73
uri: file://<WORKSPACE>/app/controllers/HomeController.scala
text:
```scala
package controllers

import play.api.mvc._
import javax.inject._

@Single@@ton
class HomeController @Inject()(cc: ControllerComponents) extends AbstractController(cc) {

  // Redirect root URL to /chart
  def index() = Action {
    Redirect("/chart")
  }
}

```


#### Short summary: 

empty definition using pc, found symbol in pc: scala/Singleton#
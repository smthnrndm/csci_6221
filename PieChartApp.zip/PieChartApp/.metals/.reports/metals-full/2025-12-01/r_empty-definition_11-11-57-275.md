error id: file://<WORKSPACE>/app/controllers/HeatMapController.scala:
file://<WORKSPACE>/app/controllers/HeatMapController.scala
empty definition using pc, found symbol in pc: 
empty definition using semanticdb
empty definition using fallback
non-local guesses:
	 -jsonString.
	 -jsonString#
	 -jsonString().
	 -scala/Predef.jsonString.
	 -scala/Predef.jsonString#
	 -scala/Predef.jsonString().
offset: 2
uri: file://<WORKSPACE>/app/controllers/HeatMapController.scala
text:
```scala
@(@@jsonString: String)(implicit request: play.api.mvc.RequestHeader)

<!DOCTYPE html>
<html>
<head>
    <title>Mental Health Risk Heatmap</title>
    <script src="https://cdn.plot.ly/plotly-latest.min.js"></script>
</head>
<body>
<h1>Mental Health Risk Heatmap</h1>

<div id="heatmap" style="width: 80%; height: 600px;"></div>

<script type="text/javascript">
    // Parse JSON string into a JavaScript object
    var dataRecords = JSON.parse('@jsonString');

    // Extract unique values for axes and facets
    var genders = [...new Set(dataRecords.map(d => d.gender))];
    var employmentStatuses = [...new Set(dataRecords.map(d => d.employment_status))];
    var workEnvironments = [...new Set(dataRecords.map(d => d.work_environment))];

    var traces = [];

    genders.forEach(function(g) {
        var z = [];
        workEnvironments.forEach(function(we) {
            var row = [];
            employmentStatuses.forEach(function(emp) {
                // find matching record
                var match = dataRecords.find(d => d.employment_status === emp && d.work_environment === we && d.gender === g);
                row.push(match ? match.avg_risk : 0);
            });
            z.push(row);
        });

        traces.push({
            z: z,
            x: employmentStatuses,
            y: workEnvironments,
            type: 'heatmap',
            name: g,
            showscale: true
        });
    });

    var layout = {
        title: 'Mental Health Risk Heatmap',
        xaxis: {title: 'Employment Status'},
        yaxis: {title: 'Work Environment'},
        grid: {rows: 1, columns: 1}
    };

    Plotly.newPlot('heatmap', traces, layout);
</script>
</body>
</html>

```


#### Short summary: 

empty definition using pc, found symbol in pc: 
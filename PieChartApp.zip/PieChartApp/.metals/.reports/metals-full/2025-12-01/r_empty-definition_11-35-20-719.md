error id: file://<WORKSPACE>/app/services/PieChartService.scala:`<error>`#`<error>`.
file://<WORKSPACE>/app/services/PieChartService.scala
empty definition using pc, found symbol in pc: 
empty definition using semanticdb

found definition using fallback; symbol CSVWriter
offset: 1039
uri: file://<WORKSPACE>/app/services/PieChartService.scala
text:
```scala
package services

import org.knowm.xchart.{PieChart, PieChartBuilder, BitmapEncoder}
import java.io.{ByteArrayOutputStream, File, FileWriter}
import java.nio.file.{Files, Paths, StandardCopyOption}
import java.util.Base64
import javax.imageio.ImageIO
import com.github.tototoshi.csv._
import scala.collection.mutable

object PieChartService {

  System.setProperty("java.awt.headless", "true")

  private val dataFolder = "data"
  private val csvFilePath = s"$dataFolder/mental_health_dataset.csv"

  // Map holds gender -> count
  private val data: mutable.Map[String, Double] = mutable.Map()

  /** Ensure CSV exists, copy from conf if first run */
  private def ensureCSVExists(): Unit = {
    val csvFile = new File(csvFilePath)
    if (!csvFile.exists()) {
      Files.createDirectories(Paths.get(dataFolder))
      val origCsv = new File("conf/mental_health_dataset.csv")
      if (origCsv.exists()) {
        Files.copy(origCsv.toPath, csvFile.toPath, StandardCopyOption.REPLACE_EXISTING)
      } else {
        val writer = CSVWrit@@er.open(csvFile)
        writer.writeRow(Seq("age","gender","employment_status")) // minimal headers
        writer.close()
      }
    }
  }

  /** Load CSV into memory, filtering employed/self-employed and counting genders */
  private def loadDataFromCSV(): Unit = {
    ensureCSVExists()
    val csvFile = new File(csvFilePath)
    val reader = CSVReader.open(csvFile)
    try {
      reader.allWithHeaders().foreach { row =>
        val employment = row.getOrElse("employment_status", "").toLowerCase
        if (employment.contains("employed")) {
          val gender = row.getOrElse("gender", "Unknown").trim
          data.update(gender, data.getOrElse(gender, 0.0) + 1.0)
        }
      }
    } finally reader.close()
  }

  /** Add a new gender count to memory and CSV */
  def addGenderCount(gender: String, count: Double): Unit = synchronized {
    val newValue = data.getOrElse(gender, 0.0) + count
    data.update(gender, newValue)

    // Append new row to CSV (minimal row to avoid schema issues)
    val csvFile = new File(csvFilePath)
    val writer = CSVWriter.open(new FileWriter(csvFile, true))
    writer.writeRow(Seq("", gender, "Employed")) // blank age, gender, employment
    writer.close()
  }

  /** Generate Base64 Pie Chart */
  def generatePieChartBase64(): String = {
    if (data.isEmpty) data.update("No Data", 1)
    val chart: PieChart = new PieChartBuilder()
      .width(600)
      .height(400)
      .title("Gender Distribution of Workers")
      .build()
    data.foreach { case (label, value) => chart.addSeries(label, value) }
    val baos = new ByteArrayOutputStream()
    val img = BitmapEncoder.getBufferedImage(chart)
    ImageIO.write(img, "png", baos)
    Base64.getEncoder.encodeToString(baos.toByteArray)
  }

  /** Return read-only copy of current data */
  def getCurrentData(): Map[String, Double] = data.toMap

  // Load CSV on startup → original chart available immediately
  loadDataFromCSV()
}

```


#### Short summary: 

empty definition using pc, found symbol in pc: 
error id: file://<WORKSPACE>/app/services/MentalHealthPredictor.scala:java/io/File#
file://<WORKSPACE>/app/services/MentalHealthPredictor.scala
empty definition using pc, found symbol in pc: java/io/File#
empty definition using semanticdb
empty definition using fallback
non-local guesses:
	 -java/io/File#
	 -File#
	 -scala/Predef.File#
offset: 541
uri: file://<WORKSPACE>/app/services/MentalHealthPredictor.scala
text:
```scala
package services

import com.github.tototoshi.csv.CSVReader
import java.io.File
import scala.collection.mutable.LinkedHashMap

object MentalHealthPredictor {

  /** Safely convert a string to Double; return 0.0 if conversion fails */
  private def toDoubleSafe(s: String): Double = try s.toDouble catch { case _: NumberFormatException => 0.0 }

  /** Predict outputs based on nearest neighbors in CSV */
  def predict(input: Map[String, Any], csvPath: String = "data/mental_health_dataset.csv"): Map[String, Any] = {

    val csvFile = new F@@ile(csvPath)
    val reader = CSVReader.open(csvFile)
    val rows = reader.allWithHeaders()
    reader.close()

    // Fields
    val numericFields = Seq("age", "stress_level", "sleep_hours", "physical_activity_days")
    val categoricalFields = Seq("gender", "employment_status", "work_environment", "mental_health_history", "seeks_treatment")

    /** Calculate distance between a CSV row and the input */
    def distance(row: Map[String, String]): Double = {
      // Numeric distance
      val numericDist = numericFields.map { f =>
        toDoubleSafe(row.getOrElse(f, "0")) - input(f).asInstanceOf[Double]
      }.map(d => d * d).sum

      // Categorical distance (0 if match, 1 if not)
      val catDist = categoricalFields.map { f =>
        if (row.getOrElse(f, "") == input(f)) 0.0 else 1.0
      }.sum

      math.sqrt(numericDist) + catDist
    }

    // Find 5 nearest neighbors
    val nearest = rows.sortBy(distance).take(5)

    /** Safe average for numeric fields */
    def avg(field: String): Double = nearest.map(r => toDoubleSafe(r.getOrElse(field, "0"))).sum / nearest.size

    // Majority vote for mental_health_risk
    val risk = nearest.groupBy(_("mental_health_risk"))
      .map { case (k, v) => k -> v.size }
      .maxBy(_._2)._1

    LinkedHashMap(
  "depression_score" -> avg("depression_score"),
  "anxiety_score" -> avg("anxiety_score"),
  "social_support_score" -> avg("social_support_score"),
  "productivity_score" -> avg("productivity_score"),
  "mental_health_risk" -> risk
)
  }
}

```


#### Short summary: 

empty definition using pc, found symbol in pc: java/io/File#
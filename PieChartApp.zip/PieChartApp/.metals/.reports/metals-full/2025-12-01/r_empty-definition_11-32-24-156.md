error id: file://<WORKSPACE>/app/controllers/HeatMapController.scala:local8
file://<WORKSPACE>/app/controllers/HeatMapController.scala
empty definition using pc, found symbol in pc: 
empty definition using semanticdb

found definition using fallback; symbol ControllerComponents
offset: 177
uri: file://<WORKSPACE>/app/controllers/HeatMapController.scala
text:
```scala
package controllers

import javax.inject._
import play.api.mvc._
import play.api.libs.json.Json
import services.HeatMapService

@Singleton
class HeatMapController @Inject()(cc: @@ControllerComponents) extends AbstractController(cc) {

  def showHeatmap = Action { implicit request: Request[AnyContent] =>
    val (xLabels, yLabels, zMatrix) = HeatMapService.aggregateHeatmap()

    val jsonData = Json.obj(
      "x" -> xLabels,
      "y" -> yLabels,
      "z" -> zMatrix
    )

    Ok(views.html.heatmap(Json.stringify(jsonData)))
  }
}

```


#### Short summary: 

empty definition using pc, found symbol in pc: 
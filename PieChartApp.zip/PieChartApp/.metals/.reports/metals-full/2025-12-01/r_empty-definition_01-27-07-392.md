error id: file://<WORKSPACE>/app/controllers/PieChartController.scala:controllers/`<error: <none>>`.
file://<WORKSPACE>/app/controllers/PieChartController.scala
empty definition using pc, found symbol in pc: 
empty definition using semanticdb
empty definition using fallback
non-local guesses:
	 -play/api/mvc/play.
	 -javax/inject/play.
	 -play/api/data/play.
	 -play/api/data/Forms.play.
	 -play/api/data/format/Formats.play.
	 -play.
	 -scala/Predef.play.
offset: 28
uri: file://<WORKSPACE>/app/controllers/PieChartController.scala
text:
```scala
package controllers

import @@play.api.mvc._
import javax.inject._
import services.PieChartService
import play.api.data._
import play.api.data.Forms._
import play.api.data.format.Formats._
import play.api.libs.json.Json

@Singleton
class PieChartController @Inject()(cc: ControllerComponents) extends AbstractController(cc) {

  val chartForm: Form[(String, Double)] = Form(
    tuple(
      "gender" -> nonEmptyText,
      "count" -> of[Double]
    )
  )

  /** Show chart page with original CSV data */
  def showChart() = Action { implicit request =>
    val base64Chart = PieChartService.generatePieChartBase64()
    val currentData = PieChartService.getCurrentData()
    Ok(views.html.chartWithInput(base64Chart, currentData))
  }

  /** Handle AJAX add gender count */
  def addGenderAjax() = Action { implicit request =>
    chartForm.bindFromRequest().fold(
      _ => BadRequest(Json.obj("status" -> "error", "message" -> "Invalid input")),
      { case (gender, count) =>
        PieChartService.addGenderCount(gender, count)
        val updatedChart = PieChartService.generatePieChartBase64()
        Ok(Json.obj("status" -> "success", "chart" -> updatedChart))
      }
    )
  }

  /** Optional non-AJAX fallback */
  def addGender() = Action { implicit request =>
    chartForm.bindFromRequest().fold(
      _ => Redirect(routes.PieChartController.showChart)
            .flashing("error" -> "Invalid input"),
      { case (gender, count) =>
        PieChartService.addGenderCount(gender, count)
        Redirect(routes.PieChartController.showChart)
          .flashing("success" -> s"Added $gender -> $count")
      }
    )
  }
}

```


#### Short summary: 

empty definition using pc, found symbol in pc: 
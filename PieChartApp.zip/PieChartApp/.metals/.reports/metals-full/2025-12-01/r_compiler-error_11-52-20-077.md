error id: 2231967A81E4FA8A9DD04E7BCC30AB2E
file://<WORKSPACE>/app/services/HeatMapService.scala
### java.util.NoSuchElementException: head of empty String

occurred in the presentation compiler.



action parameters:
offset: 638
uri: file://<WORKSPACE>/app/services/HeatMapService.scala
text:
```scala
package services

import java.awt.{Color, Font, Graphics2D}
import java.awt.image.BufferedImage
import java.io.ByteArrayOutputStream
import java.util.Base64
import com.github.tototoshi.csv._
import scala.collection.mutable

object HeatMapService {

  private val csvFilePath = "data/mental_health_dataset.csv"

  // Map: (gender, employment_status, work_environment) -> average mental_health_risk
  private val heatmapData: mutable.Map[(String, String, String), Double] = mutable.Map()

  /** Load CSV and compute average mental_health_risk per (gender, employment_status, work_environment) */
  def loadData(): Unit = {
    val reader = @@CSVReader.open(new java.io.File(csvFilePath))
    try {
      val rows = reader.allWithHeaders()

      val validRows = rows.filter(r =>
        r.get("employment_status").exists(_.nonEmpty) &&
        r.get("work_environment").exists(_.nonEmpty) &&
        r.get("gender").exists(_.nonEmpty) &&
        r.get("mental_health_risk").exists(_.nonEmpty)
      )

      val grouped = validRows.groupBy(r => (r("gender"), r("employment_status"), r("work_environment")))

      grouped.foreach { case ((gender, emp, work), recs) =>
        val risks = recs.flatMap(r =>
          r.get("mental_health_risk").flatMap {
            case "Low" => Some(0.0)
            case "Medium" => Some(0.5)
            case "High" => Some(1.0)
            case v => scala.util.Try(v.toDouble).toOption
          }
        )
        if (risks.nonEmpty) heatmapData.update((gender, emp, work), risks.sum / risks.size)
      }
    } finally reader.close()
  }

  /** Map risk 0.0-1.0 to a gradient color green -> yellow -> red */
  private def riskToColor(risk: Double): Color = {
    val clamped = Math.max(0.0, Math.min(1.0, risk))
    if (clamped <= 0.5) {
      val ratio = (clamped / 0.5).toFloat
      new Color(ratio, 1.0f, 0.0f)
    } else {
      val ratio = ((clamped - 0.5) / 0.5).toFloat
      new Color(1.0f, 1.0f - ratio, 0.0f)
    }
  }

  /** Generate Base64 PNG heatmap for a specific gender */
  def generateHeatMapForGenderBase64(gender: String): String = {
    if (heatmapData.isEmpty) loadData()

    val filteredData = heatmapData.filter(_._1._1 == gender)
    val xLabels = filteredData.keys.map(_._2).toSeq.distinct.sorted
    val yLabels = filteredData.keys.map(_._3).toSeq.distinct.sorted

    val cellSize = 80
    val width = xLabels.size * cellSize + 120
    val height = yLabels.size * cellSize + 120

    val image = new BufferedImage(width, height, BufferedImage.TYPE_INT_RGB)
    val g = image.createGraphics()
    g.setColor(Color.WHITE)
    g.fillRect(0, 0, width, height)

    // Draw cells
    for ((yLabel, row) <- yLabels.zipWithIndex) {
      for ((xLabel, col) <- xLabels.zipWithIndex) {
        val risk = filteredData.getOrElse((gender, xLabel, yLabel), 0.0)
        g.setColor(riskToColor(risk))
        g.fillRect(100 + col * cellSize, 50 + row * cellSize, cellSize, cellSize)

        g.setColor(Color.BLACK)
        g.drawRect(100 + col * cellSize, 50 + row * cellSize, cellSize, cellSize)

        g.setFont(new Font("Arial", Font.PLAIN, 14))
        g.drawString(f"$risk%.2f", 100 + col * cellSize + 10, 50 + row * cellSize + 40)
      }
    }

    // Draw axis labels
    g.setFont(new Font("Arial", Font.BOLD, 16))
    xLabels.zipWithIndex.foreach { case (label, i) =>
      g.drawString(label, 100 + i * cellSize + 15, 45)
    }
    yLabels.zipWithIndex.foreach { case (label, i) =>
      g.drawString(label, 10, 50 + i * cellSize + 40)
    }

    g.dispose()

    val baos = new ByteArrayOutputStream()
    javax.imageio.ImageIO.write(image, "png", baos)
    Base64.getEncoder.encodeToString(baos.toByteArray)
  }

  /** Return all genders for available data */
  def getGenders(): Seq[String] = {
    if (heatmapData.isEmpty) loadData()
    heatmapData.keys.map(_._1).toSeq.distinct.sorted
  }
}

```


presentation compiler configuration:
Scala version: 2.13.18
Classpath:
<HOME>/.cache/coursier/v1/https/repo1.maven.org/maven2/org/scala-lang/scala-library/2.13.18/scala-library-2.13.18.jar [exists ]
Options:





#### Error stacktrace:

```
scala.collection.StringOps$.head$extension(StringOps.scala:1124)
	scala.meta.internal.metals.ClassfileComparator.compare(ClassfileComparator.scala:30)
	scala.meta.internal.metals.ClassfileComparator.compare(ClassfileComparator.scala:3)
	java.base/java.util.PriorityQueue.siftUpUsingComparator(PriorityQueue.java:660)
	java.base/java.util.PriorityQueue.siftUp(PriorityQueue.java:637)
	java.base/java.util.PriorityQueue.offer(PriorityQueue.java:330)
	java.base/java.util.PriorityQueue.add(PriorityQueue.java:311)
	scala.meta.internal.metals.ClasspathSearch.$anonfun$search$3(ClasspathSearch.scala:32)
	scala.meta.internal.metals.ClasspathSearch.$anonfun$search$3$adapted(ClasspathSearch.scala:26)
	scala.collection.IterableOnceOps.foreach(IterableOnce.scala:630)
	scala.collection.IterableOnceOps.foreach$(IterableOnce.scala:628)
	scala.collection.AbstractIterator.foreach(Iterator.scala:1313)
	scala.meta.internal.metals.ClasspathSearch.search(ClasspathSearch.scala:26)
	scala.meta.internal.metals.WorkspaceSymbolProvider.search(WorkspaceSymbolProvider.scala:107)
	scala.meta.internal.metals.MetalsSymbolSearch.search$1(MetalsSymbolSearch.scala:114)
	scala.meta.internal.metals.MetalsSymbolSearch.search(MetalsSymbolSearch.scala:118)
	scala.meta.internal.pc.AutoImportsProvider.autoImports(AutoImportsProvider.scala:58)
	scala.meta.internal.pc.ScalaPresentationCompiler.$anonfun$autoImports$1(ScalaPresentationCompiler.scala:399)
	scala.meta.internal.pc.CompilerAccess.withSharedCompiler(CompilerAccess.scala:148)
	scala.meta.internal.pc.CompilerAccess.$anonfun$withInterruptableCompiler$1(CompilerAccess.scala:92)
	scala.meta.internal.pc.CompilerAccess.$anonfun$onCompilerJobQueue$1(CompilerAccess.scala:209)
	scala.meta.internal.pc.CompilerJobQueue$Job.run(CompilerJobQueue.scala:152)
	java.base/java.util.concurrent.ThreadPoolExecutor.runWorker(ThreadPoolExecutor.java:1136)
	java.base/java.util.concurrent.ThreadPoolExecutor$Worker.run(ThreadPoolExecutor.java:635)
	java.base/java.lang.Thread.run(Thread.java:840)
```
#### Short summary: 

java.util.NoSuchElementException: head of empty String
error id: file://<WORKSPACE>/app/services/MentalHealthPredictor.scala:local15
file://<WORKSPACE>/app/services/MentalHealthPredictor.scala
empty definition using pc, found symbol in pc: 
found definition using semanticdb; symbol local15
empty definition using fallback
non-local guesses:

offset: 1387
uri: file://<WORKSPACE>/app/services/MentalHealthPredictor.scala
text:
```scala
package services

import com.github.tototoshi.csv.CSVReader
import java.io.File

object MentalHealthPredictor {

  /** Predict outputs based on nearest neighbors in CSV */
  def predict(input: Map[String, Any], csvPath: String = "data/mental_health_dataset.csv"): Map[String, Any] = {

    val csvFile = new File(csvPath)
    val reader = CSVReader.open(csvFile)
    val rows = reader.allWithHeaders()
    reader.close()

    def distance(row: Map[String, String]): Double = {
      val ageDiff = row.getOrElse("age", "0").toDouble - input("age").asInstanceOf[Double]
      val stressDiff = row.getOrElse("stress_level", "0").toDouble - input("stress_level").asInstanceOf[Double]
      val sleepDiff = row.getOrElse("sleep_hours", "0").toDouble - input("sleep_hours").asInstanceOf[Double]
      val activityDiff = row.getOrElse("physical_activity_days", "0").toDouble - input("physical_activity_days").asInstanceOf[Double]

      val numericDist = math.sqrt(ageDiff*ageDiff + stressDiff*stressDiff + sleepDiff*sleepDiff + activityDiff*activityDiff)

      val categoricalFields = Seq("gender", "employment_status", "work_environment", "mental_health_history", "seeks_treatment")
      val catDist = categoricalFields.map(f => if(row.getOrElse(f,"") == input(f)) 0 else 1).sum.toDouble

      numericDist + catDist
    }

    val nearest = rows.sortBy(distance).take(5)

    def avg(field@@: String): Double = nearest.map(r => r.getOrElse(field, "0").toDouble).sum / nearest.size

    val risk = nearest.groupBy(_("mental_health_risk")).mapValues(_.size).maxBy(_._2)._1

    Map(
      "depression_score" -> avg("depression_score"),
      "anxiety_score" -> avg("anxiety_score"),
      "social_support_score" -> avg("social_support_score"),
      "productivity_score" -> avg("productivity_score"),
      "mental_health_risk" -> risk
    )
  }

}

```


#### Short summary: 

empty definition using pc, found symbol in pc: 
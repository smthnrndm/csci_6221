error id: 2231967A81E4FA8A9DD04E7BCC30AB2E
file://<WORKSPACE>/app/controllers/MentalHealthController.scala
### java.util.NoSuchElementException: head of empty String

occurred in the presentation compiler.



action parameters:
offset: 1004
uri: file://<WORKSPACE>/app/controllers/MentalHealthController.scala
text:
```scala
package controllers

import javax.inject._
import play.api.mvc._
import play.api.data._
import play.api.data.Forms._
import play.api.data.format.Formats._
import services.MentalHealthPredictor
import play.api.i18n.{I18nSupport, Messages, MessagesApi, MessagesRequest}

import scala.math._

@Singleton
class MentalHealthController @Inject()(cc: MessagesControllerComponents)
  extends MessagesAbstractController(cc) with I18nSupport {

  // Form mapping for input fields
  val predictionForm: Form[(
    Double, String, String, String, String, String, Double, Double, Double
  )] = Form(
    tuple(
      "age" -> of[Double],
      "gender" -> nonEmptyText,
      "employment_status" -> nonEmptyText,
      "work_environment" -> nonEmptyText,
      "mental_health_history" -> nonEmptyText,
      "seeks_treatment" -> nonEmptyText,
      "stress_level" -> of[Double],
      "sleep_hours" -> of[Double],
      "physical_activity_days" -> of[Double]
    )
  )

  /** Show prediction form */
  def showForm = @@Action { implicit request: MessagesRequest[AnyContent] =>
    Ok(views.html.predictMentalHealth(predictionForm, None))
  }

  /** Handle form submission and predict outputs */
  def predict = Action { implicit request: MessagesRequest[AnyContent] =>
    predictionForm.bindFromRequest().fold(
      formWithErrors => {
        BadRequest(views.html.predictMentalHealth(formWithErrors, None))
      },
      formData => {
        // Convert tuple to Map[String, Any] to pass to predictor
        val (age, gender, employment_status, work_env, mh_history, seeks_treatment, stress, sleep, activity) = formData
        val inputMap: Map[String, Any] = Map(
          "age" -> age,
          "gender" -> gender,
          "employment_status" -> employment_status,
          "work_environment" -> work_env,
          "mental_health_history" -> mh_history,
          "seeks_treatment" -> seeks_treatment,
          "stress_level" -> stress,
          "sleep_hours" -> sleep,
          "physical_activity_days" -> activity
        )

        val resultMap = MentalHealthPredictor.predict(inputMap)
        val resultMessage = resultMap.map { case (k,v) => s"$k: $v" }.mkString(", ")

        Ok(views.html.predictMentalHealth(predictionForm, Some(resultMessage)))
      }
    )
  }

}

```


presentation compiler configuration:
Scala version: 2.13.18
Classpath:
<HOME>/.cache/coursier/v1/https/repo1.maven.org/maven2/org/scala-lang/scala-library/2.13.18/scala-library-2.13.18.jar [exists ]
Options:





#### Error stacktrace:

```
scala.collection.StringOps$.head$extension(StringOps.scala:1124)
	scala.meta.internal.metals.ClassfileComparator.compare(ClassfileComparator.scala:30)
	scala.meta.internal.metals.ClassfileComparator.compare(ClassfileComparator.scala:3)
	java.base/java.util.PriorityQueue.siftUpUsingComparator(PriorityQueue.java:660)
	java.base/java.util.PriorityQueue.siftUp(PriorityQueue.java:637)
	java.base/java.util.PriorityQueue.offer(PriorityQueue.java:330)
	java.base/java.util.PriorityQueue.add(PriorityQueue.java:311)
	scala.meta.internal.metals.ClasspathSearch.$anonfun$search$3(ClasspathSearch.scala:32)
	scala.meta.internal.metals.ClasspathSearch.$anonfun$search$3$adapted(ClasspathSearch.scala:26)
	scala.collection.IterableOnceOps.foreach(IterableOnce.scala:630)
	scala.collection.IterableOnceOps.foreach$(IterableOnce.scala:628)
	scala.collection.AbstractIterator.foreach(Iterator.scala:1313)
	scala.meta.internal.metals.ClasspathSearch.search(ClasspathSearch.scala:26)
	scala.meta.internal.metals.WorkspaceSymbolProvider.search(WorkspaceSymbolProvider.scala:107)
	scala.meta.internal.metals.MetalsSymbolSearch.search$1(MetalsSymbolSearch.scala:114)
	scala.meta.internal.metals.MetalsSymbolSearch.search(MetalsSymbolSearch.scala:118)
	scala.meta.internal.pc.AutoImportsProvider.autoImports(AutoImportsProvider.scala:58)
	scala.meta.internal.pc.ScalaPresentationCompiler.$anonfun$autoImports$1(ScalaPresentationCompiler.scala:399)
	scala.meta.internal.pc.CompilerAccess.withSharedCompiler(CompilerAccess.scala:148)
	scala.meta.internal.pc.CompilerAccess.$anonfun$withInterruptableCompiler$1(CompilerAccess.scala:92)
	scala.meta.internal.pc.CompilerAccess.$anonfun$onCompilerJobQueue$1(CompilerAccess.scala:209)
	scala.meta.internal.pc.CompilerJobQueue$Job.run(CompilerJobQueue.scala:152)
	java.base/java.util.concurrent.ThreadPoolExecutor.runWorker(ThreadPoolExecutor.java:1136)
	java.base/java.util.concurrent.ThreadPoolExecutor$Worker.run(ThreadPoolExecutor.java:635)
	java.base/java.lang.Thread.run(Thread.java:840)
```
#### Short summary: 

java.util.NoSuchElementException: head of empty String
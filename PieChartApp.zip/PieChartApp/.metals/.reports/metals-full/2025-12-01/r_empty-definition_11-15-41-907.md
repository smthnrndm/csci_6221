error id: file://<WORKSPACE>/app/controllers/HeatMapController.scala:controllers/`<error: <none>>`.
file://<WORKSPACE>/app/controllers/HeatMapController.scala
empty definition using pc, found symbol in pc: 
empty definition using semanticdb
empty definition using fallback
non-local guesses:
	 -javax/inject/play.
	 -play/api/mvc/play.
	 -play.
	 -scala/Predef.play.
offset: 50
uri: file://<WORKSPACE>/app/controllers/HeatMapController.scala
text:
```scala
package controllers

import javax.inject._
import @@play.api.mvc._
import play.api.libs.json.Json
import services.HeatMapService

@Singleton
class HeatMapController @Inject()(cc: ControllerComponents) extends AbstractController(cc) {

  def showHeatmap = Action { implicit request: Request[AnyContent] =>
    // Get aggregated data from the service
    val data = HeatMapService.aggregate() // Seq[Record]

    // Convert data to JSON string
    val jsonString = Json.stringify(Json.toJson(
      data.map(r => Json.obj(
        "employment_status" -> r.employment_status,
        "work_environment" -> r.work_environment,
        "gender" -> r.gender,
        "avg_risk" -> r.mental_health_risk
      ))
    ))

    Ok(views.html.heatmap(jsonString))
  }
}

```


#### Short summary: 

empty definition using pc, found symbol in pc: 
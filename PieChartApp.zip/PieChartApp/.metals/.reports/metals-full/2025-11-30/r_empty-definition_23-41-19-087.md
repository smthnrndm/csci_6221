error id: file://<WORKSPACE>/app/controllers/HomeController.scala:local0
file://<WORKSPACE>/app/controllers/HomeController.scala
empty definition using pc, found symbol in pc: 
empty definition using semanticdb

found definition using fallback; symbol ControllerComponents
offset: 112
uri: file://<WORKSPACE>/app/controllers/HomeController.scala
text:
```scala
package controllers

import play.api.mvc._
import javax.inject._

@Singleton
class HomeController @Inject()(cc: @@ControllerComponents) extends AbstractController(cc) {

  def index() = Action {
    Redirect("/chart")
  }
}

```


#### Short summary: 

empty definition using pc, found symbol in pc: 
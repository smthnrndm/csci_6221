error id: 2231967A81E4FA8A9DD04E7BCC30AB2E
file://<WORKSPACE>/app/services/PieChartService.scala
### java.util.NoSuchElementException: head of empty String

occurred in the presentation compiler.



action parameters:
offset: 1546
uri: file://<WORKSPACE>/app/services/PieChartService.scala
text:
```scala
package services

import com.github.tototoshi.csv._
import org.knowm.xchart.{PieChart, PieChartBuilder, BitmapEncoder}
import java.io.ByteArrayOutputStream
import java.util.Base64

object PieChartService {

  // Enable headless mode for AWT
  {
    System.setProperty("java.awt.headless", "true")
  }

  case class Worker(gender: String, employment_status: String)

  /** Reads CSV from project root and returns list of Workers */
  def readCSV(filePath: String): Seq[Worker] = {
    val reader = CSVReader.open(filePath)
    val data = reader.allWithHeaders().map { row =>
      Worker(
        row.getOrElse("gender", "Unknown"),
        row.getOrElse("employment_status", "Unknown")
      )
    }
    reader.close()
    data
  }

  /** Generates gender pie chart for employed/self-employed workers as Base64 PNG */
  def generateGenderPieChart(extraRow: Option[(String, Double)] = None): String = {

    val data = readCSV("mental_health_dataset.csv") // CSV in project root

    // Filter employed/self-employed
    val employed = data.filter { w =>
      val s = w.employment_status.toLowerCase
      s.contains("employed") || s.contains("self-employed")
    }

    // Count by gender
    val counts = employed
      .groupBy(_.gender)
      .map { case (gender, list) => gender -> list.size.toDouble }
      .toList

    // Add extra row if provided
    val genderCounts = extraRow match {
      case Some((gender, count)) => counts :+ (gender -> count)
      case None => counts
    }

    // Build pie chart
    val chart: PieChart = new @@PieChartBuilder()
      .width(600)
      .height(400)
      .title("Gender Distribution of Workers")
      .build()

    genderCounts.foreach { case (label, value) => chart.addSeries(label, value) }

    // Encode as Base64 PNG
    val baos = new ByteArrayOutputStream()
    BitmapEncoder.saveBitmap(chart, baos, BitmapEncoder.BitmapFormat.PNG)
    Base64.getEncoder.encodeToString(baos.toByteArray)
  }
}

```


presentation compiler configuration:
Scala version: 2.13.18
Classpath:
<HOME>/.cache/coursier/v1/https/repo1.maven.org/maven2/org/scala-lang/scala-library/2.13.18/scala-library-2.13.18.jar [exists ]
Options:





#### Error stacktrace:

```
scala.collection.StringOps$.head$extension(StringOps.scala:1124)
	scala.meta.internal.metals.ClassfileComparator.compare(ClassfileComparator.scala:30)
	scala.meta.internal.metals.ClassfileComparator.compare(ClassfileComparator.scala:3)
	java.base/java.util.PriorityQueue.siftUpUsingComparator(PriorityQueue.java:660)
	java.base/java.util.PriorityQueue.siftUp(PriorityQueue.java:637)
	java.base/java.util.PriorityQueue.offer(PriorityQueue.java:330)
	java.base/java.util.PriorityQueue.add(PriorityQueue.java:311)
	scala.meta.internal.metals.ClasspathSearch.$anonfun$search$3(ClasspathSearch.scala:32)
	scala.meta.internal.metals.ClasspathSearch.$anonfun$search$3$adapted(ClasspathSearch.scala:26)
	scala.collection.IterableOnceOps.foreach(IterableOnce.scala:630)
	scala.collection.IterableOnceOps.foreach$(IterableOnce.scala:628)
	scala.collection.AbstractIterator.foreach(Iterator.scala:1313)
	scala.meta.internal.metals.ClasspathSearch.search(ClasspathSearch.scala:26)
	scala.meta.internal.metals.WorkspaceSymbolProvider.search(WorkspaceSymbolProvider.scala:107)
	scala.meta.internal.metals.MetalsSymbolSearch.search$1(MetalsSymbolSearch.scala:114)
	scala.meta.internal.metals.MetalsSymbolSearch.search(MetalsSymbolSearch.scala:118)
	scala.meta.internal.pc.AutoImportsProvider.autoImports(AutoImportsProvider.scala:58)
	scala.meta.internal.pc.ScalaPresentationCompiler.$anonfun$autoImports$1(ScalaPresentationCompiler.scala:399)
	scala.meta.internal.pc.CompilerAccess.withSharedCompiler(CompilerAccess.scala:148)
	scala.meta.internal.pc.CompilerAccess.$anonfun$withInterruptableCompiler$1(CompilerAccess.scala:92)
	scala.meta.internal.pc.CompilerAccess.$anonfun$onCompilerJobQueue$1(CompilerAccess.scala:209)
	scala.meta.internal.pc.CompilerJobQueue$Job.run(CompilerJobQueue.scala:152)
	java.base/java.util.concurrent.ThreadPoolExecutor.runWorker(ThreadPoolExecutor.java:1136)
	java.base/java.util.concurrent.ThreadPoolExecutor$Worker.run(ThreadPoolExecutor.java:635)
	java.base/java.lang.Thread.run(Thread.java:840)
```
#### Short summary: 

java.util.NoSuchElementException: head of empty String